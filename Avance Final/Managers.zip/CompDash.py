from LexerParser import runLexerParser


fileTxt = r"""
    programa proyecto;

    atributos
        int : atributoInt, atributoInt2, a;
        float : atributoFloat, atributoFloat2;
        char : atributoChar, atributoChar2;
        bool : atributoBool, atributoBool2;
        int : arrayInt[1 .. 10];
        float : matrizFloat[1..10, 2..20];
        int : despuesint;
        float : despuesfloat;


    metodos
        int funcion ejemploCondicional(float atributoInt, bool nans, char ab2, int prueba){
            
            int : atributoInt2,atributoInt3,atributoInt4,atributoInt5,c;

            if ((atributoInt2 >= prueba) && (atributoInt3 <= prueba)){
                escribir(nans)
                atributoInt5 = 2 + 1;
                atributoInt5 = 3 % 4;
                ab2 = 'hola';
            } elif ((atributoInt4 < prueba) || (atributoInt2 == prueba)){
                escribir(atributoInt, ab2)
            } else {
                escribir(atributoInt)
            }

            return (atributoInt)
        }

        void funcion ejemploWhile(bool flag,int g){

            bool : b;
            float : a;
            char : c;
            int : d; 

            g = ejemploCondicional(a,b,c,d);

            b = ejemploCondicional(a,b,c,d);

            while (flag == True) do {
                lee(1.2,1,2)
                a = 1.2 + 2.3;
            }

            do {
                
                a = 1 + 2;
            } while (flag == False)

         
        }

    principal(
        atributoInt = 1;
        escribir(atributoInt)
        atributoInt = 1 + (2 + 10);
        atributoFloat = 3 * ((28 / 4) % 2)*1.2;
        atributoChar = 'Palabra';
        atributoBool = True;

        arrayInt[2] = 12;
        matrizFloat[3, 5] = 20;

        atributoInt = arrayInt[2];
        atributoFloat = matrizFloat[1, 2];

        escribir(atributoInt)
        escribir(atributoFloat)
        escribir(atributoChar)     
        escribir(atributoBool)    
    )
    """
generaOBJ = True
memoria = []


f = open("ejemplo.txt", "r")
fullText =  ""
for x in f:
    fullText = fullText + x

print(fullText)

if generaOBJ:
    runLexerParser(fileTxt, generaOBJ, memoria)
else:
    obj = runLexerParser(fileTxt, generaOBJ, memoria)

